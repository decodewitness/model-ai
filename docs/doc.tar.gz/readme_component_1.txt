# model-ai	((( MODEL-AI ))) ARTIFICIAL INTELLIGENCE

Latest branch in development in artificial intelligence software (Model-Ai) version:(0.1-22b).

(C)(2021);
(August 21 2021)(07:44PM CET)

	Author:	(Vera Lo)
	E-Mail:	(development<AT>model-ai<DOT>com)

All Rights Are Reserved For The Respectful Owner.
We are not responsible for any damages caused by downloading any files from this repository,
nore are we responsible for any damage caused by downloading files which you download from our website.

This a development version: ( *** Please contact Us if you want more Information @ development <AT> model-ai.com *** )



Use this software at your own risk !!!
No intentional harm is done.


(C)(2021) 
░▄▄▄▄░
▀▀▄██►
▀▀███►
░▀███►░█►
▒▄████▀▀
(88)
1. 

model-ai


░▄▄▄▄░ ▀▀▄██► ▀▀███► ░▀███►░█► ▒▄████▀▀ (88)

    
