// INTERNET.CPP - GENERAL TERMS AND CONCEPTS FOR AI MODEL - USED BY "AI/SYSTEM/PROTOCOL.CPP"

// email protocol
char emlprot[2][16] = { "pop3", "imap" };	// add ports

// ftp
char ftpprot[1][4] = { "ftp" };


// eof