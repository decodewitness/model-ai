// (inside AI directory) AI/SAYING.CPP -- SAYINGS FOR AI MODEL (USED BY DICTIONARY.CPP)

#include <iostream>

void sayHello() { std::cout << "Hi"; }
void sayGoodbye() { std::cout << "Goodbye"; }
void askComfy() { std::cout << "How are you"; }

// speech command

// 
// speech command

// eof
