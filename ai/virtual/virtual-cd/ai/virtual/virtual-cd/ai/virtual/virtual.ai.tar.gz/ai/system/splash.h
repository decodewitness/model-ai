// (inside AI directory) AI/SPLASH.H (IN THE "AI" DIRECTORY) - USED BY AI.H
	// DISPLAYS THE AI MASK SYMBOL WHEN AI IS LOOKING FOR ENTROPY

// splashes logical prompt for information
// should be handled by a gradle routine

#include <iostream>

void splash(void) {
	std::cout << " ** ][][" << std::endl << std::endl;
}

// eof