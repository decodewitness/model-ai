#include <iostream>
#include <cstring>

#include "tree.cpp"

const int maximum_trees=2;