// CONCEPTS.CPP - USED BY "GRADLE.CPP" FOR MODEL AI
// CONTAINS MORE HEADER DEFINITIONS LIKE "DICTIONARY.CPP" FOR THE AI MODEL

#include "concept/dictionary.cpp"
#include "concept/custom.cpp"

// eof