#!/usr/bin/bash


perl ./bin/perl.pl


### EDIT SCRIPT ###