#include <string>

// database settings
const std::string DATA = "database/data/data";
const int max_entries = 5000; // will use # keys for key:data pairs

// database access
const std::string user = "ai_model";
const std::string password = "ai_codes_for_db_001";

// database values
const std::string table = "ai";
const std::string value = "ai";
const std::string aindex = "ai";
const std::string keyval = "ai";
