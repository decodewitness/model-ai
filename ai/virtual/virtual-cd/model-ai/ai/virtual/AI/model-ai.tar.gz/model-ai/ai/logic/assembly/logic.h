// /AI/LOGIC/ASSEMBLY/LOGIC.H: USED BY "/AI/LOGIC/ASSEMBLY/INPUT.CPP" TO SET THE MODE OF INPUT
#include "command.h"

// LOGIC CONTENT OVERRIDE CONTENT
//  adapt y to logic and logic to AI
//  and set y to manually override or
//  change it to 0 to not manually override.

const int y = 3;
const int logic = y;
