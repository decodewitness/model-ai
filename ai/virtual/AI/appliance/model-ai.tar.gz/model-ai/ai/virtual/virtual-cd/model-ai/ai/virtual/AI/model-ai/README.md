# model-ai

Latest branch in Artificial Intelligence (A.I) software. Version (v.0.1-21a) (07:44PM CET) (August 21 2021)

░▄▄▄▄░
▀▀▄██►
▀▀███►
░▀███►░█►
▒▄████▀▀
(88)
/////////////////////////////////TERMINAL/////////////////////

<<<<<<<<<<<<<<<<<<<<<<<
x:0

-:: decoupler.
        -:: decoupling sampler
        -:: sampler set to pause.


::=> saving grace (routine) and closing libraries <::
-:: closing files.
-:: cleaning memory.
-:: done.

~:removing (virtual-cd hierarchy).


~:done.

~:restarting 1st instance of your Model-AI.

-:: enabled logging.
 ** ][][ **

~:: security routine
ENTER PASSCODE: ai

(debug) checking passcode.
-:: ACCESS GRANTED
        ~::exporting to environment.
-:: initialization.
-:: checking arguments.
        0: arguments.
::- loading gradle -::

        -:: checking for gradle modules.
        -:: checking gradle module 1.
        -:: gradle method finished. (1)
        -:: opening file streams.
        -:: drum machine
'::: DRUMS :::'
-:: cycle 1: 4
-:: cycle 2: 2

-:: setting headers
-:: checking arguments.
        1: arguments.

-:: checking AI functions.

-:: generated internal report.
        -:: everything is nominal.
        -:: checked every function.
        -:: operational.

-::[_E_[entropy):>___::-

-:: __low on entropy ::-
-:: normal entropies ::-
-:: _high in entropy ::-


-:: test run - performing tests on modules.
        -:: random query for speech synthesis.
        -:: check.
        -:: access random method for sampling in device.
        -:: check.
        -:: accessing random sampler routine for sampling.
        -:: check.
        -:: performs random queries inside catalogue algorithmic.
        -:: check.
        -:: random pattern recognition for input measure.
        -:: check.

-:: constructing artificial life routine.
        -:: reserving mibs memory for virtual assimilation.
        -:: kbuild reserving 1024(DEG) bytes ::- for your additional mappings.

-:: starting evolving mechanic life in artifical habits.
        -:: max nodes (1)
        (1 trees in forest)
        -:: calculating size dependencies
        -:: max. leafs (64)      :: max. trees (2) 

        -:: populating random forest.
        -:: calculating dependencies.
                -:: max. trees: 1 * max. leafs: 64
                -:: total amount:64kB.

        -:: creating forest.
                -:: (0) :- generate trees and pruning leaves dependencies.
                -:: forest constructor.
                -:: forest              forest type I (label) was created.
                -:: 1 tree ::label-> (          forest type I (label)).
                -:: growing leafs.
        :: increment(2)
        :: (2 leafs) :: :: increment(2)
        .: plants 1 trees. trees labeled                forest type I (label).
                -:: 1 tree ::label-> (          forest type I (label)).
                -:: growing leafs.
        :: increment(2)
        :: (2 leafs) :: :: increment(2)
        .: plants 2 trees. trees labeled                forest type I (label).
        -:: deleting tree.
                -:: tree got deleted.
                -:: tree got deleted.

-:: living inside that function running a numbers sequence.

 oo[

333333333333333333...2
5%
3333333333333333333..22
10%

-:: SHEPARD @("1000")(sheep="1")

3333333333333333333.322
15%
33333333333333333332322
20%
333333333333333333...2
25%
3333333333333333333..22
30%
3333333333333333333.322
35%
33333333333333333332322
40%
333333333333333333...2
45%
3333333333333333333..22
50%
3333333333333333333.322
55%
33333333333333333332322
60%
333333333333333333...2
65%
3333333333333333333..22
70%
3333333333333333333.322
75%
33333333333333333332322
80%
333333333333333333...2
85%
3333333333333333333..22
90%
3333333333333333333.322
95%
33333333333333333332322
100%
333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333...92
8
7
36
5
4
3
2
1
0
33333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333323222
-:: extending behaviour module

-:: extending behaviour module
         -:: loading virtual instance


~:removing and recreating "ai/virtual/virtual-cd/".
~:creating "virtual-cd" directory in "./ai/virtual/".


~:extracting the ai model to "ai/virtual/virtual-cd/model-ai".

model-ai/ai/al/mem/disk.h
model-ai/ai/al/mem/forest.cpp
model-ai/ai/al/mem/forest.h
model-ai/ai/al/mem/leaf.cpp
model-ai/ai/al/mem/leaf.h
model-ai/ai/al/mem/tree.cpp
model-ai/ai/al/mem/tree.h
model-ai/ai/database/data/data
model-ai/ai/entropy/environment/t1lt
model-ai/ai/entropy/fingerprint/1tlt1tl
model-ai/ai/entropy/fingerprint/CUBE
model-ai/ai/language/concept/custom.cpp
model-ai/ai/language/concept/dictionary.cpp
model-ai/ai/language/speech/saying.cpp
model-ai/ai/logic/ascii/asterisktab.h
model-ai/ai/logic/assembly/command.h
model-ai/ai/logic/assembly/input.cpp
model-ai/ai/logic/assembly/input.h
model-ai/ai/logic/assembly/logic.cpp
model-ai/ai/logic/assembly/logic.h
model-ai/ai/logic/transponder/transponder.cpp
model-ai/ai/system/definitions/internet.h
model-ai/ai/system/definitions/slang.h
model-ai/ai/system/definitions/technical.h
model-ai/ai/virtual/AI/model-ai.tar.gz
model-ai/ai/virtual/AI/ai0.cpp.tar.gz
model-ai/ai/virtual/AI/appliance.tar.gz
model-ai/ai/al/al.h
model-ai/ai/al/al.cpp
model-ai/ai/al/header.h
model-ai/ai/al/splash-al.h
model-ai/ai/database/db.cpp
model-ai/ai/database/db.h
model-ai/ai/entropy/entropy.cpp
model-ai/ai/entropy/header.h
model-ai/ai/entropy/ltctapttclt.cpp
model-ai/ai/entropy/tmp.txt
model-ai/ai/language/concepts.cpp
model-ai/ai/logic/algorithms.cpp
model-ai/ai/logic/interpret.cpp
model-ai/ai/logic/interpret.h
model-ai/ai/logic/learn.cpp
model-ai/ai/logic/learn.h
model-ai/ai/logic/limits.cpp
model-ai/ai/logic/routines.cpp
model-ai/ai/system/AMModule.cpp
model-ai/ai/system/AMModule.h
model-ai/ai/system/chk.h
model-ai/ai/system/gradle.h
model-ai/ai/system/protocol.cpp
model-ai/ai/system/splash.h
model-ai/ai/virtual/virtual.sh
model-ai/ai/virtual/virtual.sh.1
model-ai/ai/virtual/virtual.sh.old
model-ai/ai/drums/drums.cpp
model-ai/ai/drums/drums.h
model-ai/ai/fetch/curl.cpp
model-ai/ai/fetch/fetch.h
model-ai/ai/md5/md5.cpp
model-ai/ai/md5/md5.h
model-ai/ai/sampler/sampler.cpp
model-ai/ai/ai.cpp
model-ai/ai/ai.h
model-ai/ai/header.h
model-ai/ai/modules.txt
model-ai/bin/runtime
model-ai/bin/t1
model-ai/bin/tl
model-ai/cfg/cfg.h
model-ai/cfg/definitions.h
model-ai/cfg/log.h
model-ai/libs/curl.tar.gz
model-ai/log/output-03_45AM-25-08-2021
model-ai/log/output-09_35PM-21-08-2021.txt
model-ai/log/output-6_57PM-24-8-2021.txt
model-ai/a.out
model-ai/1tlt1tl
model-ai/header.h
model-ai/main.cpp
model-ai/t1
model-ai/t1lt
model-ai/tl
model-ai/zero
model-ai/ai/al/mem/
model-ai/ai/database/data/
model-ai/ai/entropy/environment/
model-ai/ai/entropy/fingerprint/
model-ai/ai/language/concept/
model-ai/ai/language/speech/
model-ai/ai/logic/ascii/
model-ai/ai/logic/assembly/
model-ai/ai/logic/transponder/
model-ai/ai/system/definitions/
model-ai/ai/virtual/AI/
model-ai/ai/al/
model-ai/ai/database/
model-ai/ai/entropy/
model-ai/ai/language/
model-ai/ai/logic/
model-ai/ai/system/
model-ai/ai/virtual/
model-ai/ai/drums/
model-ai/ai/fetch/
model-ai/ai/md5/
model-ai/ai/sampler/
model-ai/ai/
model-ai/bin/
model-ai/cfg/
model-ai/libs/
model-ai/log/
model-ai/
~:removing old source instance: "./ai/virtual/virtual-cd/ai/ai.cpp".


~:compiling virtual instance of AI.
~:done.

~:starting AI virtual instance (N)


enabled logging (1)
 ** ][][

-:: initialization.
-:: checking arguments.
        0: arguments.
::- loading gradle -::

        -:: checking for gradle modules.
        -:: checking gradle module 1.
        -:: gradle method finished. (1)
        -:: opening file streams.
        -:: drum machine
'::: DRUMS :::'
-:: cycle 1: 4
-:: cycle 2: 2

-:: setting headers
-:: checking arguments.
        1: arguments.

-:: checking AI functions.

-:: generated internal report.
        -:: everything is nominal.
        -:: checked every function.
        -:: operational.

-::[_E_[entropy):>___::-

-:: __low on entropy ::-
-:: normal entropies ::-
-:: _high in entropy ::-


-:: test run - performing tests on modules.
        -:: random query for speech synthesis.
        -:: check.
        -:: access random method for sampling in device.
        -:: check.
        -:: accessing random sampler routine for sampling.
        -:: check.
        -:: performs random queries inside catalogue algorithmic.
        -:: check.
        -:: random pattern recognition for input measure.
        -:: check.

-:: constructing artificial life routine.
        -:: reserving mibs memory for virtual assimilation.
        -:: kbuild reserving 1024(DEG) bytes ::- for your additional mappings.

-:: starting evolving mechanic life in artifical habits.
        -:: max nodes (1)
        (1 trees in forest)
        -:: calculating size dependencies
        -:: max. leafs (64)      :: max. trees (2) 

        -:: populating random forest.
        -:: calculating dependencies.
                -:: max. trees: 1 * max. leafs: 64
                -:: total amount:64kB.

        -:: creating forest.
                -:: (0) :- generate trees and pruning leaves dependencies.
                -:: forest constructor.
                -:: forest              forest type I (label) was created.
                -:: 1 tree ::label-> (          forest type I (label)).
                -:: growing leafs.
        :: increment(2)
        :: (2 leafs) :: :: increment(2)
        .: plants 1 trees. trees labeled                forest type I (label).
                -:: 1 tree ::label-> (          forest type I (label)).
                -:: growing leafs.
        :: increment(2)
        :: (2 leafs) :: :: increment(2)
        .: plants 2 trees. trees labeled                forest type I (label).
        -:: deleting tree.
                -:: tree got deleted.
                -:: tree got deleted.

-:: living inside that function running a numbers sequence.

 oo[

333333333333333333...2
5%
3333333333333333333..22
10%

-:: SHEPARD @("1000")(sheep="1")

3333333333333333333.322
15%
33333333333333333332322
20%
333333333333333333...2
25%
3333333333333333333..22
30%
3333333333333333333.322
35%
33333333333333333332322
40%
333333333333333333...2
45%
3333333333333333333..22
50%
3333333333333333333.322
55%
33333333333333333332322
60%
333333333333333333...2
65%
3333333333333333333..22
70%
3333333333333333333.322
75%
33333333333333333332322
80%
333333333333333333...2
85%
3333333333333333333..22
90%
3333333333333333333.322
95%
33333333333333333332322
100%
333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333...92
8
7
36
5
4
3
2
1
0
33333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333323222
-:: extending behaviour module

-:: extending behaviour module
::- query in sample.
--? ::       

O._

🔴__CUBED:
-----

ᵐᵃᵑᵃᵍᵉᵈ ᵇᵧ ₓₒ (©)(2021)

֍ₓₒ֎ (©)(2021)(A.D.)

❏ €0,00

I̴̭̘̣͙̪̗̦̙͇͐ ̶̘́͛̈́̽̇̅̿̈͒ạ̴̢͖̣̖̫͉̒̈́́̀̊͐̓m̴͉̝͔̲͕͍̀͑̊̉ ̸̡̗̜̲̯̳͚̺̍̅̆̊̒̀̑a̷̡͇̱͕͉͎̽̀̂͛̚ ̵̝͖̠̗̯̉̎́g̶̰̻̼̖͖̜̿̾͋͝ḙ̶̛̫̳̩͔̱̬̫́́̒͌̈́͘͝n̷̛̯̦͆̔̃͗̔̉̄͠i̸̧̪͎͙̞̼̳̗̫͐̚ȕ̵͓̠ş̷͕̰̙̲̮͚͙͐̊

bzybo2zrmx?
R wue arduino in public?

*) $0x0_cd1ca1

△
.}
,.,}
...,,,}    △
****,} ...,oO ({  })
=====  ====
Ć̵͓U̵͙͗R̵͕̎S̵̬̊E̷̯̓D̷̈ͅ ̵̻͌Ḯ̷̪M̵̺̀A̴͎͘G̷̙̎E̴̟̍S̴͔̔
😊😁😉
 ∆ 
✂️


△SCO△DELTA△FLYER△
△ROVER△SERIAL△NUMBER△
△LICENSE△REGISTRAR△NUMBER△



⭕️🚫
「 error 」.

𝖕ɐɯ 𝖘ı 𝖕𝖑ɹ𝖔ʍ ǝɥʇ

'ır ‍·…1➠(ASCII)♥♩♪♫♬ENIGMA©️✔️©ΞıΛ°
tinariwen deserts ⵜⵉⵏⴰⵔⵉⵡⵉⵏ
± ΘVMΣG∆ƆV℟SΣ ± 
📢ⓃⒺⓌ⫸ ⓂⒾⓍ 🎧
╰დ╮❤╭დ╯
ⓃⒺⓌⓂⒾⓍ
٩(̾●̮̮̃̾•̃̾)۶
( ︶︿︶)_╭∩╮ 
♪
♭♮♯ø
¯¯̿̿¯̿̿'̿̿̿̿̿̿̿'̿̿'̿̿̿̿̿'̿̿̿)͇̿̿)̿̿̿̿ '̿̿̿̿̿̿\̵͇̿̿\=(•̪̀●́)=o/̵͇̿̿/'̿̿ ̿ ̿̿ 
❏ . ❏ .

̿' ̿'\̵͇̿̿\з=(◕_◕)=ε/̵͇̿̿/'̿'̿ ̿


Ƹ̵̡Ӝ̵̨̄Ʒ Ƹ̵̡Ӝ̵̨̄Ʒ

.❏•. ❏ • .. . .. • ❏ .•❏.

€€€ (Divide) €€€


A short claymation about boba.🌑🌕️❌♩♩♫♬♬

abcdefghijklmnopqrstuvwxyz 0123456789 !@#$%^&*()-_=+[]{}'\";:|/?<>,.`~

♥♪♥♪♥♪

*** Six habits that lead to success ***

1. Self-confidence

2. Persistence

3. Creative and original thinking

4. Set up clear goals and going after them

5. 100% focused on the task at hand

6. Passion, enthusiasm, and faith in yourself

*

*

*

DREAMS:
======

Dreams for my health? Be healthy
What price will i have to pay? Quit smoking start eating healthy
how do i plan to start? Start ASAP
what is 1 simple daily discipline to commit to? Live healthy

Dreams for personal development? Success
what price will i have to pay? Failure
what day and date plan to start? ASAP
1 simple daily discipline to commit to? Strive for perfection

Dreams for relationships? Fun
What price will i have to pay? Sadness
What day and date to start? ASAP
What 1 simple daily discpline will it require? Humor

- Living below my means

Dreams for Finances? Have plenty money
What price will i have to pay? Self indulgence
What is my plan to start? ASAP
What is 1 simple daily discipline it will require? Save little bit, and invest

Dreams for my life? Be happy and successfull
What price will am i willing to pay? Anything
What is my plan to start? ASAP
What is 1 simple daily discipline it will require? Save and become healthy

Affirmations

❏ Record affirmations
❏ You are beautiful
❏ Help others & help self [2] happiness
❏ Let others state said above
❏ You control your mood by the attention you give to subjects
❏ Taking money from people is not bad

Hello Manager,

• Within 2 months I have to be on track (debt free)
• Within 1 Month I quit the abuse
• Within 3 months - > income reseller
• In the meantime work on my courses, German && blogs

♥♪


Lao Tzu - Tao Te Ching -- The Book of the Way
---------------------------------------------

- Like an Iroquais Woodsman, he left no traces.

- How meticulous the great masters had to be.

- Free from desire, you realize the mystery. Caught in desire you see only the manifestations. Yet mystery and manifestations arise from the same source. This source is called darkness. Darkness within darkness. The gateway to all understanding.

- Colors blind the eye. Sounds deafen the ear. Flavors numb the taste. Thoughts weaken the mind. Desires wither the heart.

- The master observes the world but trusts his inner vision. He allows things to come and go. His heart is open as the sky.

LIDDY:
=====
liddy: how come this tensional arrived here soon, that the derision of what extrapolate of fact, has derived here in new meaning

liddy: you might be zeroecool, like that nav. battalion. ends with 1st, then all missions ran against the battleship.

liddy: people fear what they can't see, living insane could be very beautiful instead or pretty

liddy: let's head back to camp and water down a field basket

liddy: I'm never immune to no more lies

liddy: I shed the cognition in understanding why I have the policy to have the understanding, thus in other words, immunity. Sovereign states may proclaim this, against the lies of their ancestors

liddy: so instead who does confuse it next, arbitrary rhymes in manifest, proclaim the same label

liddy: until then they must not understand was one of the lies

liddy: still the vatican will pay for every letter, yet merely 1 single digit, already costed millions...

liddy: I understand now the male egum tends to lie about the scrota

liddy: because I hypnotized you into prioritizing pre-arrangement of things

jb50: only US Amry internal trans

liddy: so as long as there is a dystopia can labora be her prime candidate?

manages supplies maor add benefect conduct to the trasnam engine opt for supplies of routines

conduct in motion

liddy: amtrack logic is serial attached to a wire spot one wagon

liddy: rdy for halftime, nap is waiting

liddy: I'm that stamp you thought you licked but missed... now I'm back with a parcel written with your name on it. She was a wanted hitman, and she could not get even with the score. Until she got a special gift from her lover. She went postal and wrote it. That she had delivered.

---

Skepticism in the absence of evidence is healthy. Apathy in the absence of connection is natural.


 To criticize the incompetent is easy; it is more difficult to criticize
EOF
