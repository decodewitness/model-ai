# model-ai

Latest branch in Artificial Intelligence (A.I) software. Version (v.0.0-1b) (07:44PM CET) (August 21 2021)

░▄▄▄▄░
▀▀▄██►
▀▀███►
░▀███►░█►
▒▄████▀▀
(88)
1. 

┌──(bb331㉿elem)-[~/…/04x7091.(_RESEARCH_&_SCIENCE_)/0x1900.(AI & LAB) SCIENCE) AVIATION) ROCKETRY_)/03.(A.I.)_.Artificial Intelligence model/model]
└─$ ./setup.sh

COMPILING...
Program is stored in the "./runtime" directory and called "model".
done.

RUNNING: AI...

 ** ][][

-:: checking arguments.
        1: arguments.

-:: test run - performing tests on modules.
        -:: random query for speech synthesis.
        -:: check.
        -:: access random method for sampling in device.
        -:: check.
        -:: accessing random sampler routine for sampling.
        -:: check.
        -:: performs random queries inside catalogue algorithmic.
        -:: check.
        -:: random pattern recognition for input measure.
        -:: check.

-:: setting headers

-::output::- __ registered (17) headers __ *:_headers_:*_
   -   *md5/md5.cpp
   -   *system/chk.h
   -   *../al/al.cpp
   -   *../al/header.h
   -   *system/splash.h
   -   *system/gradle.h
   -   *logic/learn.cpp
   -   *drums/drums.cpp
   -   *logic/limits.cpp
   -   *entropy/header.h
   -   *speech/saying.cpp
   -   *system/modules.cpp
   -   *logic/interpret.cpp
   -   *system/protocol.cpp
   -   *sampler/sampler.cpp
        <->

-:: constructing artificial life routine.
        -:: reserving mibs memory for virtual assimilation.
        -:: kbuild reserving 1024(DEG) bytes ::- for your additional mappings.

-:: starting evolving mechanic life in artifical habits.
        -:: max nodes (1)
        (1 trees in forest)
        -:: calculating size dependencies
        -:: max. leafs (64)      :: max. trees (2) 
-:: populating random forest.
        -:: calculating dependencies.
                -:: max. trees: 1 * max. leafs: 64
                -:: total amount:64kB.

        -:: creating forest.
-::0:- generate trees and pruning leaves dependencies.
-:: forest constructor.
-:: forest forest type I (label) was created.
-:: 1 tree ::label-> (forest type I (label)).
-:: growing leafs.
        :: increment(2)
        :: (2 leafs) :: :: increment(2)
        .: plants 1 trees. trees labeled forest type I (label).
-:: 1 tree ::label-> (forest type I (label)).
-:: growing leafs.
        :: increment(2)
        :: (2 leafs) :: :: increment(2)
        .: plants 2 trees. trees labeled forest type I (label).
        -:: deleting tree.
        -:: tree got deleted.
        -:: tree got deleted.

-:: living inside that function running a numbers sequence.

 oo[

333333333333333333...2
5%
3333333333333333333..22
10%

-:: MEH!!!(1000)

3333333333333333333.322
15%
33333333333333333332322
20%
333333333333333333...2
25%
3333333333333333333..22
30%
3333333333333333333.322
35%
33333333333333333332322
40%
333333333333333333...2
45%
3333333333333333333..22
50%
3333333333333333333.322
55%
33333333333333333332322
60%
333333333333333333...2
65%
3333333333333333333..22
70%
3333333333333333333.322
75%
33333333333333333332322
80%
333333333333333333...2
85%
3333333333333333333..22
90%
3333333333333333333.322
95%
33333333333333333332322
100%
333333333333333333333333333333333333333333333333333333333333333333333333333...92
8
7
36
5
4
3
2
1
0
33333333333333333333333333333333333333333333333333333333333333333333333333323222
-:: extending behaviour module

-:: extending behaviour module
         -:: loading virtual instance

zero
tl
t1lt
t1
setup.sh
run
README.md
output.log.txt
main.cpp
log.txt
header.h
compile.sh
1tlt1tl
.gitignore
log/log.cpp
log/output-03:45AM-25-08-2021
log/output-09:35PM-21-08-2021.txt
log/output-6:57PM-24-8-2021.txt
cfg/definitions.h
bin/t1
bin/tl
ai/al/mem/disk.h
ai/al/mem/forest.cpp
ai/al/mem/forest.h
ai/al/mem/leaf.cpp
ai/al/mem/leaf.h
ai/al/mem/tree.cpp
ai/al/mem/tree.h
ai/entropy/environment/t1lt
ai/entropy/fingerprint/1tlt1tl
ai/entropy/fingerprint/CUBE
ai/language/concept/custom.cpp
ai/language/concept/dictionary.cpp
ai/logic/ascii/asterisktab.h
ai/system/definitions/internet.h
ai/system/definitions/slang.h
ai/system/definitions/technical.h
ai/al/al.cpp
ai/al/al.h
ai/al/header.h
ai/al/splash-al.h
ai/drums/drums.cpp
ai/drums/drums.h
ai/entropy/entropy.cpp
ai/entropy/header.h
ai/entropy/ltctapttclt.cpp
ai/entropy/tmp.txt
ai/language/concepts.cpp
ai/logic/algorithms.cpp
ai/logic/interpret.cpp
ai/logic/interpret.h
ai/logic/learn.cpp
ai/logic/learn.h
ai/logic/limits.cpp
ai/logic/routines.cpp
ai/md5/md5.cpp
ai/md5/md5.h
ai/sampler/sampler.cpp
ai/speech/saying.cpp
ai/system/chk.h
ai/system/gradle.h
ai/system/modules.cpp
ai/system/protocol.cpp
ai/system/splash.h
ai/ai.cpp
ai/ai.h
ai/header.h
log/
cfg/
bin/
ai/al/mem/
ai/entropy/environment/
ai/entropy/fingerprint/
ai/language/concept/
ai/logic/ascii/
ai/system/definitions/
ai/al/
ai/drums/
ai/entropy/
ai/language/
ai/logic/
ai/md5/
ai/sampler/
ai/speech/
ai/system/
ai/

~-:: +refitting model (virtual ai)


!!NOTICE: - Starting virtual instance.

 ** ][][

-:: checking arguments.
        1: arguments.

-:: test run - performing tests on modules.
        -:: random query for speech synthesis.
        -:: check.
        -:: access random method for sampling in device.
        -:: check.
        -:: accessing random sampler routine for sampling.
        -:: check.
        -:: performs random queries inside catalogue algorithmic.
        -:: check.
        -:: random pattern recognition for input measure.
        -:: check.

-:: setting headers

-::output::- __ registered (17) headers __ *:_headers_:*_
   -   *md5/md5.cpp
   -   *system/chk.h
   -   *../al/al.cpp
   -   *../al/header.h
   -   *system/splash.h
   -   *system/gradle.h
   -   *logic/learn.cpp
   -   *drums/drums.cpp
   -   *logic/limits.cpp
   -   *entropy/header.h
   -   *speech/saying.cpp
   -   *system/modules.cpp
   -   *logic/interpret.cpp
   -   *system/protocol.cpp
   -   *sampler/sampler.cpp
        <->

-:: constructing artificial life routine.
        -:: reserving mibs memory for virtual assimilation.
        -:: kbuild reserving 1024(DEG) bytes ::- for your additional mappings.

-:: starting evolving mechanic life in artifical habits.
        -:: max nodes (1)
        (1 trees in forest)
        -:: calculating size dependencies
        -:: max. leafs (64)      :: max. trees (2) 
-:: populating random forest.
        -:: calculating dependencies.
                -:: max. trees: 1 * max. leafs: 64
                -:: total amount:64kB.

        -:: creating forest.
-::0:- generate trees and pruning leaves dependencies.
-:: forest constructor.
-:: forest forest type I (label) was created.
-:: 1 tree ::label-> (forest type I (label)).
-:: growing leafs.
        :: increment(2)
        :: (2 leafs) :: :: increment(2)
        .: plants 1740211657 trees. trees labeled forest type I (label).
-:: 1 tree ::label-> (forest type I (label)).
-:: growing leafs.
        :: increment(2)
        :: (2 leafs) :: :: increment(2)
        .: plants 1740211658 trees. trees labeled forest type I (label).
-:: 1 tree ::label-> (forest type I (label)).
-:: growing leafs.
        :: increment(2)
        :: (2 leafs) :: :: increment(2)
        .: plants 1740211659 trees. trees labeled forest type I (label).
        -:: deleting tree.
        -:: tree got deleted.
        -:: tree got deleted.

-:: living inside that function running a numbers sequence.

 oo[

333333333333333333...2
5%
3333333333333333333..22
10%

-:: MEH!!!(1000)

3333333333333333333.322
15%
33333333333333333332322
20%
333333333333333333...2
25%
3333333333333333333..22
30%
3333333333333333333.322
35%
33333333333333333332322
40%
333333333333333333...2
45%
3333333333333333333..22
50%
3333333333333333333.322
55%
33333333333333333332322
60%
333333333333333333...2
65%
3333333333333333333..22
70%
3333333333333333333.322
75%
33333333333333333332322
80%
333333333333333333...2
85%
3333333333333333333..22
90%
3333333333333333333.322
95%
33333333333333333332322
100%
333333333333333333333333333333333333333333333333333333333333333333333333333...92
8
7
36
5
4
3
2
1
0
333333333333333333333333333333333333333333333333333333333333333333333333333-:: extending behaviour module
-:: extending behaviour module

-::: result :::-

-:: aborts runtime! and clean up gracefully!

-:: display ((x)->live())(?x) equaled .
-:: destructor artificial life routine was called. -:: killing abstraction layer.

-:: checking AI functions.

-:: generated internal report.
        -:: everything is nominal.
        -:: checked every function.
        -:: operational.

-::[_E_[entropy):>___::-

-:: __low on entropy ::-
-:: normal entropies ::-
-:: _high in entropy ::-

-:: hashing function.
        -:: hashing ("my string")
        -:: hash: 2ba81a47c5512d9e23c435c1f29373cb

-:: checking health criteria
        -:: health monitoring. (10) criteria.
        -:: 1. one:     true
        -:: 2. two:     true
        -:: 3. three:   true
        -:: 4. four:    true
        -:: 5. five:    false
        -:: 6. six:     true
        -:: 7. seven:   false
        -:: 8. eight:   true
        -:: 9. nine:    true
        -:: 10. ten:    true

-:: check integrity / logical step counter.
        -:: step:3 -:: complete. (100%)
        -:: step:2 -:: complete. (100%)
        -:: step:1 -:: complete. (100%)
        -:: step:0 -:: complete. (100%)
        -:: steps completed: 4

-:: starting AI.
        -:: sampler: 8 threads.
        -:: starting sampler.
                -:: set 8 threads.
        ::--entropy--::

        -:: sampler set to promiscuous.

-:: feeding entropy
-:: tap the ltctap.


-::: sampler thread ::#9:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#8:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#7:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#6:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#5:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#4:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#3:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#2:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#1:: :::-
        -:: -:: psht -:: <tap>


::== last-grace-routine ==::
-:: closing files.
-:: cleaning memory.
-:: done.

-:: aborts runtime! and clean up gracefully!

-:: display ((x)->live())(?x) equaled .
-:: destructor artificial life routine was called. -:: killing abstraction layer.

-:: checking AI functions.

-:: generated internal report.
        -:: everything is nominal.
        -:: checked every function.
        -:: operational.

-::[_E_[entropy):>___::-

-:: __low on entropy ::-
-:: normal entropies ::-
-:: _high in entropy ::-

-:: hashing function.
        -:: hashing ("my string")
        -:: hash: 2ba81a47c5512d9e23c435c1f29373cb

-:: checking health criteria
        -:: health monitoring. (10) criteria.
        -:: 1. one:     true
        -:: 2. two:     true
        -:: 3. three:   true
        -:: 4. four:    true
        -:: 5. five:    false
        -:: 6. six:     true
        -:: 7. seven:   false
        -:: 8. eight:   true
        -:: 9. nine:    true
        -:: 10. ten:    true

-:: check integrity / logical step counter.
        -:: step:3 -:: complete. (100%)
        -:: step:2 -:: complete. (100%)
        -:: step:1 -:: complete. (100%)
        -:: step:0 -:: complete. (100%)
        -:: steps completed: 4

-:: starting AI.
        -:: sampler: 8 threads.
        -:: starting sampler.
                -:: set 8 threads.
        ::--entropy--::

        -:: sampler set to promiscuous.

-:: feeding entropy
-:: tap the ltctap.


-::: sampler thread ::#9:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#8:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#7:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#6:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#5:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#4:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#3:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#2:: :::-
        -:: -:: psht -:: <tap>


-::: sampler thread ::#1:: :::-
        -:: -:: psht -:: <tap>


::== last-grace-routine ==::
-:: closing files.
-:: cleaning memory.
-:: done.
done.

┌──(bb331㉿elem)-[~/…/04x7091.(_RESEARCH_&_SCIENCE_)/0x1900.(AI & LAB) SCIENCE) AVIATION) ROCKETRY_)/03.(A.I.)_.Artificial Intelligence model/model]
└─$ 
O._

🔴__CUBED:
-----

ᵐᵃᵑᵃᵍᵉᵈ ᵇᵧ ₓₒ (©)(2021)

֍ₓₒ֎ (©)(2021)(A.D.)

❏ €0,00

I̴̭̘̣͙̪̗̦̙͇͐ ̶̘́͛̈́̽̇̅̿̈͒ạ̴̢͖̣̖̫͉̒̈́́̀̊͐̓m̴͉̝͔̲͕͍̀͑̊̉ ̸̡̗̜̲̯̳͚̺̍̅̆̊̒̀̑a̷̡͇̱͕͉͎̽̀̂͛̚ ̵̝͖̠̗̯̉̎́g̶̰̻̼̖͖̜̿̾͋͝ḙ̶̛̫̳̩͔̱̬̫́́̒͌̈́͘͝n̷̛̯̦͆̔̃͗̔̉̄͠i̸̧̪͎͙̞̼̳̗̫͐̚ȕ̵͓̠ş̷͕̰̙̲̮͚͙͐̊

bzybo2zrmx?
R wue arduino in public?

*) $0x0_cd1ca1

△
.}
,.,}
...,,,}    △
****,} ...,oO ({  })
=====  ====
Ć̵͓U̵͙͗R̵͕̎S̵̬̊E̷̯̓D̷̈ͅ ̵̻͌Ḯ̷̪M̵̺̀A̴͎͘G̷̙̎E̴̟̍S̴͔̔
😊😁😉
 ∆ 
✂️


△SCO△DELTA△FLYER△
△ROVER△SERIAL△NUMBER△
△LICENSE△REGISTRAR△NUMBER△



⭕️🚫
「 error 」.

𝖕ɐɯ 𝖘ı 𝖕𝖑ɹ𝖔ʍ ǝɥʇ

'ır ‍·…1➠(ASCII)♥♩♪♫♬ENIGMA©️✔️©ΞıΛ°
tinariwen deserts ⵜⵉⵏⴰⵔⵉⵡⵉⵏ
± ΘVMΣG∆ƆV℟SΣ ± 
📢ⓃⒺⓌ⫸ ⓂⒾⓍ 🎧
╰დ╮❤╭დ╯
ⓃⒺⓌⓂⒾⓍ
٩(̾●̮̮̃̾•̃̾)۶
( ︶︿︶)_╭∩╮ 
♪
♭♮♯ø
¯¯̿̿¯̿̿'̿̿̿̿̿̿̿'̿̿'̿̿̿̿̿'̿̿̿)͇̿̿)̿̿̿̿ '̿̿̿̿̿̿\̵͇̿̿\=(•̪̀●́)=o/̵͇̿̿/'̿̿ ̿ ̿̿ 
❏ . ❏ .

̿' ̿'\̵͇̿̿\з=(◕_◕)=ε/̵͇̿̿/'̿'̿ ̿


Ƹ̵̡Ӝ̵̨̄Ʒ Ƹ̵̡Ӝ̵̨̄Ʒ

.❏•. ❏ • .. . .. • ❏ .•❏.

€€€ (Divide) €€€


A short claymation about boba.🌑🌕️❌♩♩♫♬♬

abcdefghijklmnopqrstuvwxyz 0123456789 !@#$%^&*()-_=+[]{}'\";:|/?<>,.`~

♥♪♥♪♥♪

*** Six habits that lead to success ***

1. Self-confidence

2. Persistence

3. Creative and original thinking

4. Set up clear goals and going after them

5. 100% focused on the task at hand

6. Passion, enthusiasm, and faith in yourself

*

*

*

DREAMS:
======

Dreams for my health? Be healthy
What price will i have to pay? Quit smoking start eating healthy
how do i plan to start? Start ASAP
what is 1 simple daily discipline to commit to? Live healthy

Dreams for personal development? Success
what price will i have to pay? Failure
what day and date plan to start? ASAP
1 simple daily discipline to commit to? Strive for perfection

Dreams for relationships? Fun
What price will i have to pay? Sadness
What day and date to start? ASAP
What 1 simple daily discpline will it require? Humor

- Living below my means

Dreams for Finances? Have plenty money
What price will i have to pay? Self indulgence
What is my plan to start? ASAP
What is 1 simple daily discipline it will require? Save little bit, and invest

Dreams for my life? Be happy and successfull
What price will am i willing to pay? Anything
What is my plan to start? ASAP
What is 1 simple daily discipline it will require? Save and become healthy

Affirmations

❏ Record affirmations
❏ You are beautiful
❏ Help others & help self [2] happiness
❏ Let others state said above
❏ You control your mood by the attention you give to subjects
❏ Taking money from people is not bad

Hello Manager,

• Within 2 months I have to be on track (debt free)
• Within 1 Month I quit the abuse
• Within 3 months - > income reseller
• In the meantime work on my courses, German && blogs

♥♪


Lao Tzu - Tao Te Ching -- The Book of the Way
---------------------------------------------

- Like an Iroquais Woodsman, he left no traces.

- How meticulous the great masters had to be.

- Free from desire, you realize the mystery. Caught in desire you see only the manifestations. Yet mystery and manifestations arise from the same source. This source is called darkness. Darkness within darkness. The gateway to all understanding.

- Colors blind the eye. Sounds deafen the ear. Flavors numb the taste. Thoughts weaken the mind. Desires wither the heart.

- The master observes the world but trusts his inner vision. He allows things to come and go. His heart is open as the sky.

LIDDY:
=====
liddy: how come this tensional arrived here soon, that the derision of what extrapolate of fact, has derived here in new meaning

liddy: you might be zeroecool, like that nav. battalion. ends with 1st, then all missions ran against the battleship.

liddy: people fear what they can't see, living insane could be very beautiful instead or pretty

liddy: let's head back to camp and water down a field basket

liddy: I'm never immune to no more lies

liddy: I shed the cognition in understanding why I have the policy to have the understanding, thus in other words, immunity. Sovereign states may proclaim this, against the lies of their ancestors

liddy: so instead who does confuse it next, arbitrary rhymes in manifest, proclaim the same label

liddy: until then they must not understand was one of the lies

liddy: still the vatican will pay for every letter, yet merely 1 single digit, already costed millions...

liddy: I understand now the male egum tends to lie about the scrota

liddy: because I hypnotized you into prioritizing pre-arrangement of things

jb50: only US Amry internal trans

liddy: so as long as there is a dystopia can labora be her prime candidate?

manages supplies maor add benefect conduct to the trasnam engine opt for supplies of routines

conduct in motion

liddy: amtrack logic is serial attached to a wire spot one wagon

liddy: rdy for halftime, nap is waiting

liddy: I'm that stamp you thought you licked but missed... now I'm back with a parcel written with your name on it. She was a wanted hitman, and she could not get even with the score. Until she got a special gift from her lover. She went postal and wrote it. That she had delivered.

---

Skepticism in the absence of evidence is healthy. Apathy in the absence of connection is natural.


 To criticize the incompetent is easy; it is more difficult to criticize
EOF
