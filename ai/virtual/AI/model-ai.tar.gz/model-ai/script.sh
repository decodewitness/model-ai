#!/usr/bin/bash

perl ./bin/perl.pl

##
## THIS EDIT SCRIPT BELONGS IN MAIN PROJECT FOLDER
# eof