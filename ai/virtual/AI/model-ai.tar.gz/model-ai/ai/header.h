#include "al/al.cpp"

void start_hal() {
    HAL hal;
}