//  AI/SYSTEM/DEFINITIONS/TECHNICAL.CPP - FOR MODELING AI - USED BY "AI/SYSTEM/PROTOCOL.CPP"

std::string wwwdata[16] = {"http://", "https://", "http://www.", "https://www.", "port 80", "port:80", "port 443", "port:443" };

