//  AI/SYSTEM/PROTOCOL.CPP  -   DEFINITIONS KNOWN BY AI FOR AI MODEL    -   USED BY "AI.H"

#include <cstring>

#include "definitions/slang.h"
#include "definitions/internet.h"
#include "definitions/technical.h"

// eof