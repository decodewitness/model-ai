//  "AI/LOGIC/ASCII/ASTERISKTAB.H" - USED BY "AI/AI.H" - FOR MODELLING AI MODEL

// asterisktab
const std::string asterisktab = "   -   *";

// eof