//  "AI/LOGIC/INTERPRET.CPP" - INTERPRET TEXT MODEL FOR THE AI CLASS MODEL - USED BY "AI/AI.H"
#include "interpret.h"

// interprets
std::string language_construct;

// temporary containers
std::string tempA;
std::string tempB;

// result container
std::string result;

// eof