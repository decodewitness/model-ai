#include <iostream>
#include <cstring>

#include "logic.cpp"

void finished() {
    std::cout << "-:: finished computation." << std::endl;
}
