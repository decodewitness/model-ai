//AI/LOGIC/ASSEMBLY/COMMAND.H: USED BY /AI/LOGIC/ASSEMBLY/LOGIC.H

#include <cstring>

std::string readln = "read ln";
std::string readlnlen = "read ln len";
std::string compute =   "perform x computation";
