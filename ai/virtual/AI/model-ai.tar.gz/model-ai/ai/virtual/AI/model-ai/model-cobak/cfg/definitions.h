// DEFINITIONS.H - USED BY "HEADER.H" FOR MODEL AI
// DEFINITIONS FILE FOR THE AI CLASS TESTING:

// definitions
const int speech = 1;
const int methods = 2;
const int routines = 3;
const int catalogue = 4;
const int recognition = 5;

// eof