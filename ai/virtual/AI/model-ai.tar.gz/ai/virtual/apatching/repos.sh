#!/usr/bin/bash

wget https://thatbot.ninja/archive.tar.gz

# EOF