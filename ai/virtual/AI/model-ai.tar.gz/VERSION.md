### MODEL-AI ###

Version: (0.1-21a)
Author: mtb landv.
Year: 2021
Date: 6-Nov

COPYRIGHT(2021)(C);